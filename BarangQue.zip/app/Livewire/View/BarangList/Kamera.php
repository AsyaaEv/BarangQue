<?php

namespace App\Livewire\View\BarangList;

use Livewire\Component;

class Kamera extends Component
{
    public function render()
    {
        return view('livewire.view.barang-list.kamera');
    }
}
