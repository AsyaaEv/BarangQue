@extends('index')
@section('content')
    <div class="w-full h-auto">
        <div class="py-4 px-4">
            @livewire('view.testimonis')
        </div>
    </div>
@endsection