<div class="w-auto h-auto">
    @include('components.navbar')
</div>
