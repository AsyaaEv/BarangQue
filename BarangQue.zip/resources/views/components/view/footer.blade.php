<div class="w-full h-auto bottom-0 ">
    <div class="w-full h-auto bg-primary p-4" data-aos='fade-up' data-aos-once="true">
        <div class="w-full h-auto flex flex-col border-b-2 pb-2">
            <div class="text-3xl font-bold text-white">Barang<span class="text-sec">Que</span></div>
            <div class="text-white">Solusi mudah untuk memenuhi kebutuhan semua warga SMK Negeri 1 Bangsri.</div>
            <div class="text-white">Partner project : waque.rifalkom.my.id - M Rifal Prasetyo</div>
        </div>
        <div class="w-full h-auto flex mt-2 justify-center items-center text-sm">
            <i class="ph ph-copyright text-white"></i><div class="text-white">Copyright BarangQue 2024</div>
        </div>
    </div>
</div>