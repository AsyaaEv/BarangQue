<?php $__env->startSection('content'); ?>
    <div class="w-full h-screen bg-gray-100 flex justify-center items-center ">
        <?php echo $__env->make('view.tos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div
            class="w-[90%] h-[90%] bg-white gap-4 border-2 rounded-[10px] shadow px-4 flex justify-center items-center flex-col">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.register');

$__html = app('livewire')->mount($__name, $__params, 'lw-1516325036-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tefas\Documents\BarangQue\resources\views/dashboard/register/register.blade.php ENDPATH**/ ?>