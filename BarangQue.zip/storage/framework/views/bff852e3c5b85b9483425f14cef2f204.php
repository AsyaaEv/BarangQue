<div class="w-full h-auto">
    <div class="rounded-[20px] px-[1rem] py-[1rem] mb-4 flex flex-col gap-[20px]">
        <div class="w-full h-auto flex justify-between  border-b-2  pb-[1rem]">
            <div class="w-full h-auto flex gap-[10px] items-center ">
                <i class="ph ph-users text-2xl"></i>
                <div class="">List User</div>
            </div>
        </div>
        <div class="w-full max-h-[20rem] flex flex-col gap-[10px] justify-center items-center overflow-auto">
            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="w-full h-auto border-2 shadow rounded-[10px] px-4 py-2 flex justify-center items-center gap-[10px]">
                <div class="w-auto h-auto flex ">
                    <img src="<?php echo e(Storage::url('public/' .$item->foto)); ?>" alt="" class="w-[3rem] h-[3rem] object-cover rounded-full ">
                </div>
                <div class="w-full h-auto flex justify-between items-center">
                    <div class="w-full h-auto ">
                        <div class="font-bold text-xl"><?php echo e($item->name); ?></div>
                        <div class=""><?php echo e($item->email); ?></div>
                    </div>
                    <div class="w-auto h-auto">
                        <button class=" bg-primary rounded-[10px]" data-ripple-light="true" data-dialog-close="true" wire:click='add(<?php echo e($item->id); ?>)'>
                            <i class="ph ph-plus text-white p-4 "></i>
                        </button>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <div class="w-full h-auto flex justify-end items-center">
            <button class="p-2 rounded-[10px] bg-primary text-white" data-dialog-close="true" >Close</button>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\tefas\Documents\BarangQue\resources\views/livewire/dashboard/master/popup-add.blade.php ENDPATH**/ ?>