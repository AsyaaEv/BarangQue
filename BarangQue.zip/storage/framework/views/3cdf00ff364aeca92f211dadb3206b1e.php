<section class="w-full h-auto mt-[5rem]">
    <main class="w-full h-auto">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('view.profile');

$__html = app('livewire')->mount($__name, $__params, 'lw-3820316345-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </main>
</section><?php /**PATH C:\Users\tefas\Documents\BarangQue\resources\views/components/profile/profile.blade.php ENDPATH**/ ?>