
<?php $__env->startSection('content'); ?>
    <div class="w-full h-screen flex justify-center items-center">
        <div class="w-auto h-auto p-8 m-2 bg-white shadow border-2 rounded-[20px]">
            <div class="w-full h-auto flex justify-center items-center">
                <img src="<?php echo e(Storage::url('src/assets/vForgetPassword.svg')); ?>" alt="" class="w-[15rem] h-[15rem] pointer-events-none">
            </div>
            <div class="w-full h-auto flex flex-col justify-center items-center mb-4">
                <div class="font-bold text-2xl text-primary">Barang<span class="text-sec">Que</span></div>
                <div class="">Masukan nomor WA untuk mengganti password</div>
                <div class="text-sm text-red-500">*Pastikan nomor WA terhubung dengan akun anda</div>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.forget-password');

$__html = app('livewire')->mount($__name, $__params, 'lw-2059654441-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tefas\Documents\BarangQue\resources\views/dashboard/forget-password.blade.php ENDPATH**/ ?>