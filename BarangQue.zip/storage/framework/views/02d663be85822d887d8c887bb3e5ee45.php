<div id="testimoni" class="absolute"></div>
<section class="w-full h-auto mt-4 flex justify-center items-center flex-col px-4" data-aos='fade-right' data-aos-once="true">
    <div class="w-full h-auto  gap-[10px]">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('view.testi');

$__html = app('livewire')->mount($__name, $__params, 'lw-2532186269-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>
</section>
<?php /**PATH C:\Users\tefas\Documents\BarangQue\resources\views/components/view/testi.blade.php ENDPATH**/ ?>