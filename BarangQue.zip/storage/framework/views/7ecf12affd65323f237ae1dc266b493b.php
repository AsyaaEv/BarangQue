
<?php $__env->startSection('content'); ?>
    <div class="w-full h-auto">
        <div class="py-4 px-4">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('view.testimonis');

$__html = app('livewire')->mount($__name, $__params, 'lw-435480089-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tefas\Documents\BarangQue\resources\views/view/testimonis.blade.php ENDPATH**/ ?>