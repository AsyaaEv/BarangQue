<div class="w-auto h-auto">
    <?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH C:\Users\tefas\Documents\BarangQue\resources\views/components/layout.blade.php ENDPATH**/ ?>