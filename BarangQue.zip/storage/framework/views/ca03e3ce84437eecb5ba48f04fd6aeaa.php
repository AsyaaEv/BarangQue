<?php $__env->startSection('content'); ?>
    <div class="w-full h-auto">
        <?php echo $__env->make('components.view.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="py-4 px-4">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('view.barang-list.index');

$__html = app('livewire')->mount($__name, $__params, 'lw-3851338481-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tefas\Documents\BarangQue\resources\views/view/list-barang.blade.php ENDPATH**/ ?>