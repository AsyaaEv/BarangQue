<div>
    <div
        class="flex items-center p-4 font-sans text-2xl antialiased font-semibold leading-snug shrink-0 text-blue-gray-900">
        Kembalikan Barang Pinjaman
    </div>
    <div
        class="relative p-4 font-sans text-base antialiased font-light leading-relaxed border-t border-b border-t-blue-gray-100 border-b-blue-gray-100 text-blue-gray-500">
        Apakah kamu yakin untuk mengembalikan barang pinjaman?
    </div>
    <div class="flex flex-wrap items-center justify-end p-4 shrink-0 text-blue-gray-500">
        <button data-ripple-dark="true" data-dialog-close="true"
            class="px-6 py-3 mr-1 font-sans text-xs font-bold text-red-500 uppercase transition-all rounded-lg middle none center hover:bg-red-500/10 active:bg-red-500/30 disabled:pointer-events-none disabled:opacity-50 disabled:shadow-none">
            Batal
        </button>
        <button data-ripple-light="true" data-dialog-close="true" wire:click='borrow'
            class="middle none center rounded-lg bg-primary py-3 px-6 font-sans text-xs font-bold uppercase text-white shadow-md shadow-green-500/20 transition-all hover:shadow-lg hover:shadow-green-500/40 active:opacity-[0.85] disabled:pointer-events-none disabled:opacity-50 disabled:shadow-none">
            Kembalikan
        </button>
    </div>
</div>
<?php /**PATH C:\Users\tefas\Documents\BarangQue\resources\views/livewire/dashboard/barang/borrow.blade.php ENDPATH**/ ?>